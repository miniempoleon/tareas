//: [Previous](@previous)

import Foundation

struct Odometer{
    var count:Int=0
    mutating func increment(){
        self.count += 1
    }
}
var instanciaOdometro = Odometer(count: 10)
for _ in 1...10{
    instanciaOdometro.increment()
    print(instanciaOdometro.count)
    
}
instanciaOdometro.count
var str = "Hello, playground"

//: [Next](@next)
