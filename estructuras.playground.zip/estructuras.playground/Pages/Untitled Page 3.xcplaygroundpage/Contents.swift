//: [Previous](@previous)

import Foundation

struct Temperature{
    static var boilingPoint = 100
    var celsius:Double
    static func hello(){
        print("Hola mi boilingPoint es: \(boilingPoint)")
    }
}
var instanciaTemp1 = Temperature(celsius: 200.0)
instanciaTemp1.celsius
var instanciaTemp2 = Temperature(celsius: 400.0)
instanciaTemp2.celsius
var instanciaTemp3 = instanciaTemp2
instanciaTemp3.celsius = -1000

Temperature.boilingPoint
Temperature.boilingPoint = 10
Temperature.boilingPoint
Temperature.hello()

let smallerNumber = Double.minimum(10, -10)
smallerNumber

//: [Next](@next)
