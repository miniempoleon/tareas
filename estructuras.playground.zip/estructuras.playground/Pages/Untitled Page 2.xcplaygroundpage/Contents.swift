//: [Previous](@previous)

import Foundation
struct StepCounter{
    var totalSteps:Int=0{
        willSet{
            print("About to set totalSteps to \(newValue)")
        }
        didSet{
            if(totalSteps>oldValue){
                print("Added \(totalSteps-oldValue) Steps")
            }
        }
    }
}


var pasosDennis = StepCounter()
pasosDennis.totalSteps
pasosDennis.totalSteps=10
pasosDennis.totalSteps
pasosDennis.totalSteps=15
pasosDennis.totalSteps
var str = "Hello, playground"

//: [Next](@next)
