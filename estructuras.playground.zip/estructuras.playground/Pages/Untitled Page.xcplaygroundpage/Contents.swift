import UIKit

struct Temperatura{
    var celsius:Double
    var fahrenheit:Double{
        return celsius * 1.8 + 32
    }
    init(celsius:Double){
        self.celsius = celsius
    }
}

var instanciaTemperatura = Temperatura(celsius: 100.0)
instanciaTemperatura.celsius
instanciaTemperatura.fahrenheit
instanciaTemperatura.celsius=0
instanciaTemperatura.fahrenheit

var str = "Hello, playground"
