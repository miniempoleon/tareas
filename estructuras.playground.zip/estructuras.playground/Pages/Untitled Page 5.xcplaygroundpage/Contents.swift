//: [Previous](@previous)

import Foundation
struct Temperatura{
    var celsius:Double
    var fahrenheit:Double
    var kelvin:Double
    init(celsius:Double){
        self.celsius=celsius
        fahrenheit = celsius*1.8+32
        kelvin = celsius + 273.15
    }
    init(fahrenheit:Double){
        self.fahrenheit=fahrenheit
        celsius = (fahrenheit-32)/1.8
        kelvin = celsius + 273.15
    }
    init(kelvin:Double){
        self.kelvin=kelvin
        celsius = (kelvin-273.15)
        fahrenheit = celsius*1.8+32
    }
}
var instancia = Temperatura.init(kelvin: <#T##Double#>)
var str = "Hello, playground"

//: [Next](@next)
